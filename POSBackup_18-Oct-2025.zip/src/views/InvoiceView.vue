<template>
  <div class="container">
    <div class="header">
        <h2>Invoices</h2>
        <div class="actions">
            <button class="action-button" @click="router.push('/invoices/new')">Add New Invoice</button>
            <button class="action-button">Filter by Date</button>
        </div>
    </div>

    <input
      type="text"
      v-model="searchQuery"
      placeholder="Search by party name..."
      class="search-box"
    />

    <div class="invoice-list-container">
        <div v-if="loading" class="loading">Loading...</div>
        <div v-if="error" class="error">{{ error }}</div>

        <ul v-if="filteredInvoices.length" class="invoice-list">
          <li v-for="invoice in filteredInvoices" :key="invoice.id" class="invoice-card">
            <div class="invoice-header" @click="toggleInvoice(invoice)">
                <div class="header-content">
                    <div class="header-main-line">
                        <span>{{ invoice.edate }}</span>
                        <strong>{{ invoice.partyname }}</strong>
                        <span class="total-amount">{{ formatCurrency(calculateTotal(invoice)) }}</span>
                    </div>
                    <div class="header-sub-line">
                        <span>Entered by: {{ invoice.enterredby }}</span>
                        <div class="invoice-actions">
                            <button class="action-button-small" @click.stop="alterInvoice(invoice)">Alter</button>
                            <button class="action-button-small" @click.stop="printInvoice(invoice)">Print</button>
                        </div>
                    </div>
                </div>
                <span class="explode-symbol">{{ invoice.isExpanded ? 'v' : '›' }}</span>
            </div>
            <div v-if="invoice.isExpanded">
              <div class="item-list-header">
                  <span>Item Name</span>
                  <span>Qty</span>
                  <span>Rate</span>
                  <span class="amount-header">Amount</span>
              </div>
              <ul class="item-list-inner">
                <li v-for="(item, index) in invoice.invoiceitem" :key="index" class="item-card-inner">
                  <div class="item-line">
                    <span>{{ item.itemname }}</span>
                    <span>{{ item.qty }}</span>
                    <span>{{ item.rate }}</span>
                    <span class="amount">{{ formatCurrency(item.amount) }}</span>
                  </div>
                </li>
              </ul>
            </div>
          </li>
        </ul>
        <div v-else-if="!loading" class="no-results">
          No invoices found.
        </div>
    </div>

    <div v-if="filteredInvoices.length" class="total-line">
        <strong>Grand Total</strong>
        <span class="total-amount">{{ formatCurrency(grandTotal) }}</span>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, createApp } from 'vue';
import { useRouter } from 'vue-router';
import html2pdf from 'html2pdf.js';
import PrintableInvoice from '../components/PrintableInvoice.vue';
import axios from 'axios';
import { useSessionStore } from '@/stores/session';
import { useApiStore } from '@/stores/api';

const router = useRouter();

const invoices = ref([]);
const loading = ref(true);
const error = ref(null);
const searchQuery = ref('');
const sessionStore = useSessionStore();
const apiStore = useApiStore();

onMounted(async () => {
  try {
    const dosname = sessionStore.getDosName;
    const apiBaseUrl = apiStore.apiBaseUrl;
    const response = await axios.get(`${apiBaseUrl}/api/pos/ListOfAllinvoices?fromdate=1&todate=22001231&companyno=${dosname}`);
    invoices.value = response.data && response.data.data
      ? response.data.data.map(invoice => ({ ...invoice, isExpanded: false }))
      : [];
  } catch (e) {
    error.value = 'Failed to fetch invoices: ' + e.message;
    console.error(e);
  } finally {
    loading.value = false;
  }
});

const calculateTotal = (invoice) => {
  return invoice.invoiceitem.reduce((total, item) => total + item.amount, 0);
};

const formatCurrency = (value) => {
  if (typeof value !== 'number') {
        return '0.00';
    }
  return value.toFixed(2);
};

const toggleInvoice = (invoice) => {
  invoice.isExpanded = !invoice.isExpanded;
};

const filteredInvoices = computed(() => {
  if (!searchQuery.value) {
    return invoices.value;
  }
  return invoices.value.filter(invoice =>
    invoice.partyname.toLowerCase().includes(searchQuery.value.toLowerCase())
  );
});

const grandTotal = computed(() => {
    return filteredInvoices.value.reduce((total, invoice) => total + calculateTotal(invoice), 0);
});

const printInvoice = (invoice) => {
  const printContainer = document.createElement('div');
  document.body.appendChild(printContainer);

  const app = createApp(PrintableInvoice, { invoice });
  app.mount(printContainer);

  const opt = {
    margin:       1,
    filename:     `invoice-${invoice.id}.pdf`,
    image:        { type: 'jpeg', quality: 0.98 },
    html2canvas:  { scale: 2 },
    jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
  };

  html2pdf().from(printContainer).set(opt).save().then(() => {
    app.unmount();
    document.body.removeChild(printContainer);
  });
};

const alterInvoice = (invoice) => {
  router.push({ name: 'new-invoice', state: { invoice: JSON.stringify(invoice) } });
};

const notImplemented = () => {
  alert('This feature is not yet implemented.');
};
</script>

<style scoped>
.container {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 80px); /* Increased height */
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.actions {
    display: flex;
    gap: 10px;
}

.action-button {
    padding: 8px 12px;
    border: none;
    background-color: #007aff;
    color: white;
    border-radius: 8px;
    cursor: pointer;
}

.invoice-list-container {
    flex-grow: 1;
    overflow-y: auto;
}

h2 {
  text-align: center;
  margin: 0;
}

.search-box {
  width: 100%;
  padding: 12px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 16px;
}

.loading, .no-results, .error {
  text-align: center;
  padding: 20px;
  color: #888;
}

.error {
  color: #f14668;
}

.invoice-list {
  list-style: none;
  padding: 0;
}

.invoice-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  margin-bottom: 10px;
  padding: 15px;
}

.invoice-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
}

.header-content {
    flex-grow: 1;
}

.header-main-line {
    display: flex;
    justify-content: space-between;
    width: 100%;
}

.header-sub-line {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.8em;
    color: #6c757d;
    margin-top: 4px;
}

.invoice-actions {
    display: flex;
    gap: 5px;
}

.action-button-small {
    padding: 4px 8px;
    border: none;
    background-color: #007aff;
    color: white;
    border-radius: 4px;
    cursor: pointer;
    margin-right: 5px;
    font-size: 0.8em;
}

.invoice-header strong {
  font-size: 1.2em;
  flex-grow: 1;
  padding: 0 10px;
}

.total-amount {
  font-weight: bold;
  text-align: right;
}

.explode-symbol {
    font-size: 1.2em; /* Lighter font */
    font-weight: normal;
    margin-left: 15px;
    width: 20px; /* Fixed width for alignment */
    text-align: center;
}

.item-list-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background-color: #87ceeb; /* skyblue */
    font-weight: bold;
    margin-top: 15px;
    border-top: 1px solid #eee;
}

.amount-header {
    text-align: right;
}

.item-list-inner {
  list-style: none;
  padding: 0;
}

.item-card-inner {
  padding: 0 10px;
  border-bottom: 1px solid #eee;
}

.item-card-inner:last-child {
  border-bottom: none;
}

.item-line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  font-size: 0.8em; /* tiny font */
  color: #0000ff; /* blue */
}

.amount {
  text-align: right;
}

.total-line {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    margin-top: 20px;
    border-top: 2px solid #333;
    font-size: 1.2em;
}
</style>