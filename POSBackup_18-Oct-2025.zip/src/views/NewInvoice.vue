<template>
  <div class="new-invoice-layout">
    <div class="invoice-form-container">
      <div class="invoice-form">
        <div class="form-header">
          <h2>New Invoice</h2>
          <button @click="sendInvoice" class="send-btn">Save Invoice</button>
        </div>

        <div class="customer-info">
            <div class="form-row">
                <input type="text" placeholder="Customer Name" v-model="customerName" @focus="showParties" @input="filterParties" class="party-name-input"/>
                <input type="date" v-model="date" class="invoice-date-input"/>
            </div>
            <div class="form-row">
                <input type="text" placeholder="Invoice Number" class="invoice-number-input" v-model="invoiceNumber"/>
                <select v-model="vchType" class="vch-type-select">
                    <option value="sales">Sales</option>
                    <option value="purchase">Purchase</option>
                    <option value="issue">Issue</option>
                </select>
            </div>
        </div>

        <table class="items-table">
            <thead>
                <tr>
                    <th>Actions</th>
                    <th>Item Name</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <div class="scrollable-tbody">
                <tbody>
                    <tr v-for="(item, index) in items" :key="index">
                        <td>
                            <button @click="editItem(index)" class="action-btn">✏️</button>
                            <button @click="removeItem(index)" class="action-btn">❌</button>
                        </td>
                        <td>{{ item.itemname }}</td>
                        <td>{{ item.qty }}</td>
                        <td>{{ item.price }}</td>
                        <td>{{ (item.qty * item.price).toFixed(2) }}</td>
                    </tr>
                </tbody>
            </div>
        </table>

        <div class="total-section">
            <strong>Total: {{ total.toFixed(2) }}</strong>
        </div>

        <div class="add-item-form">
            <input v-model="currentItem.itemname" placeholder="Enter item name" @focus="showStock" />
            <input v-model.number="currentItem.qty" type="number" placeholder="Qty" />
            <input v-model.number="currentItem.price" type="number" placeholder="Price" />
            <button @click="addItem" class="add-btn">{{ editingIndex === null ? 'Add' : 'Update' }}</button>
        </div>
      </div>
    </div>
    <div class="suggestion-container">
        <div v-if="rightPanelContent === 'stock'">
            <h3>Stock Items</h3>
            <ul class="suggestion-list">
                <li v-for="item in filteredStockItems" :key="item.id" @click="selectStockItem(item)" class="suggestion-item">
                    <strong>{{ item.name }}</strong>
                    <div>Rate: {{ item.preRate }} | Qty: {{ item.closingQty }}</div>
                </li>
            </ul>
        </div>
        <div v-if="rightPanelContent === 'parties'">
            <h3>Customers</h3>
            <ul class="suggestion-list">
                <li v-for="party in filteredParties" :key="party.id" @click="selectParty(party)" class="suggestion-item">
                    <strong>{{ party.name }}</strong>
                    <div>Balance: {{ party.balance }}</div>
                </li>
            </ul>
        </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useSessionStore } from '@/stores/session';
import { useRouter } from 'vue-router';
import axios from 'axios';

const router = useRouter();
const sessionStore = useSessionStore();
const selectedDb = computed(() => sessionStore.getDosName);

const items = ref([]);
const currentItem = ref({ id: null, itemname: "", qty: null, price: null });
const editingIndex = ref(null);
const stockItems = ref([]);
const parties = ref([]);
const customerName = ref('');
const invoiceNumber = ref('');
const selectedPartyId = ref(null);
const date = ref(new Date().toISOString().substr(0, 10));
const vchType = ref('sales');
const rightPanelContent = ref('stock'); // 'stock' or 'parties'

const total = computed(() => items.value.reduce((acc, item) => acc + item.qty * item.price, 0));

const filteredStockItems = computed(() => {
    if (!currentItem.value.itemname) return stockItems.value;
    return stockItems.value.filter(item =>
        item.name.toLowerCase().includes(currentItem.value.itemname.toLowerCase())
    );
});

const filteredParties = computed(() => {
    if (!customerName.value) return parties.value;
    return parties.value.filter(party =>
        party.name.toLowerCase().includes(customerName.value.toLowerCase())
    );
});

function showStock() {
    rightPanelContent.value = 'stock';
}

function showParties() {
    rightPanelContent.value = 'parties';
}

function filterParties() {
    rightPanelContent.value = 'parties';
}

function selectStockItem(item) {
    currentItem.value = { ...currentItem.value, id: item.id, itemname: item.name, price: item.preRate };
}

function selectParty(party) {
    customerName.value = party.name;
    selectedPartyId.value = party.id;
}

function addItem() {
    if (!currentItem.value.itemname || !currentItem.value.qty || !currentItem.value.price) return;
    if (editingIndex.value !== null) {
        items.value[editingIndex.value] = { ...currentItem.value };
        editingIndex.value = null;
    } else {
        items.value.push({ ...currentItem.value });
    }
    currentItem.value = { id: null, itemname: "", qty: null, price: null };
}

function editItem(index) {
    editingIndex.value = index;
    currentItem.value = { ...items.value[index] };
}

function removeItem(index) {
    items.value.splice(index, 1);
}

async function sendInvoice() {
    const invoiceData = {
        dosname: selectedDb.value,
        invoice: {
            partyid: selectedPartyId.value,
            partyname: customerName.value,
            date: date.value.replace(/-/g, ''),
            vchname: vchType.value,
            invoiceitem: items.value.map(item => ({
                itemid: item.id,
                itemname: item.itemname,
                qty: item.qty,
                rate: item.price,
                amount: item.qty * item.price,
            })),
        },
    };

    if (invoiceNumber.value) {
        invoiceData.invoice.name = invoiceNumber.value;
    }

    console.log('Sending invoice data:', JSON.stringify(invoiceData, null, 2));

    try {
        const dosname = sessionStore.getDosName;
        const response = await axios.post(`/api/POS/Createnewinvoicefromjson?companyno=${dosname}`, invoiceData);

        console.log('Invoice saved:', response.data);
        router.push({ name: 'invoice' });
    } catch (e) {
        console.error(e);
    }
}

onMounted(async () => {
  try {
    const dosname = sessionStore.getDosName;
    const stockResponse = await axios.get(`/api/POS/ListOfAllItems?companyno=${dosname}`);
    const partyResponse = await axios.get(`/api/POS/ListOfAllPersons?companyno=${dosname}`);

    stockItems.value = stockResponse.data.data;
    parties.value = partyResponse.data.data;

    if (history.state.invoice) {
      const invoiceToAlter = JSON.parse(history.state.invoice);
      customerName.value = invoiceToAlter.partyname;
      invoiceNumber.value = invoiceToAlter.name;
      const year = String(invoiceToAlter.date).substring(0, 4);
      const month = String(invoiceToAlter.date).substring(4, 6);
      const day = String(invoiceToAlter.date).substring(6, 8);
      date.value = `${year}-${month}-${day}`;
      vchType.value = invoiceToAlter.vchname.toLowerCase();
      selectedPartyId.value = invoiceToAlter.partyid;
      items.value = invoiceToAlter.invoiceitem.map(item => ({
        id: item.itemid,
        itemname: item.itemname,
        qty: item.qty,
        price: item.rate,
      }));
    }

  } catch (e) {
    console.error(e);
  }
});
</script>

<style scoped>
.new-invoice-layout {
    display: flex;
    height: 100vh;
    background-color: #f9f9f9;
}

.invoice-form-container {
    width: 60%;
    padding: 20px;
    display: flex;
    flex-direction: column;
}

.invoice-form {
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 20px;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.form-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.invoice-number-input {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
    margin: 0 15px;
}

.send-btn {
    background-color: #007aff;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
}

.customer-info {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 20px;
}

.customer-info input {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
}

.form-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
}

.party-name-input {
    width: 70%;
}

.invoice-date-input {
    width: 28%;
}

.invoice-number-input {
    width: 70%;
}

.vch-type-select {
    width: 28%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
}

.items-table {
    width: 100%;
    border-collapse: collapse;
    flex-grow: 1;
}

.items-table th, .items-table td {
    padding: 4px; /* Reduced padding */
    border-bottom: 1px solid #eee;
    text-align: left;
    line-height: 1.2em;
    font-size: 0.9em;
}

.items-table tbody tr:nth-child(odd) {
  background-color: #f9f9f9; /* Light gray for odd rows */
}

.items-table tbody tr:nth-child(even) {
  background-color: #ffffff; /* White for even rows */
}

.items-table th {
    background-color: #f2f2f2;
}

.action-btn {
    border: none;
    background: none;
    cursor: pointer;
}

.total-section {
    text-align: right;
    margin-top: 20px;
    font-size: 1.2em;
    font-weight: bold;
}

.add-item-form {
    display: flex;
    gap: 10px;
    margin-top: 20px;
    align-items: center;
}

.add-item-form input {
    flex-grow: 1;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
}

.add-btn {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
}

.suggestion-container {
    width: 40%;
    padding: 20px;
    border-left: 1px solid #ddd;
    overflow-y: auto;
    background-color: #f9f9f9;
}

.suggestion-list {
    list-style: none;
    padding: 0;
}

.suggestion-item {
    padding: 10px;
    border-bottom: 1px solid #eee;
    cursor: pointer;
}

.suggestion-item:hover {
    background-color: #f0f0f0;
}

.scrollable-tbody {
  max-height: 300px; /* Or any desired fixed height */
  overflow-y: auto;
  display: block; /* Important for scrolling div to work with table content */
}

.items-table tbody {
  display: block; /* Important for scrolling div to work with table content */
  width: 100%;
}

.items-table tr {
  display: table; /* Makes tr behave like a table row */
  width: 100%;
  table-layout: fixed; /* Ensures columns have equal width */
  height: 30px; /* Fixed height for table rows */
  /* Note: If column alignment issues occur with the scrollbar, consider setting explicit widths for th and td elements. */
}
</style>
