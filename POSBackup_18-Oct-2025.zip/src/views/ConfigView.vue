<template>
  <div class="config-container">
    <h2>API Configuration</h2>
    <div class="input-group">
      <label for="api-url">API Base URL:</label>
      <input
        id="api-url"
        type="text"
        v-model="currentApiUrl"
        placeholder="e.g., http://localhost:4590"
      />
    </div>
    <div class="button-group">
      <button @click="saveConfig" class="save-button">Save</button>
      <button @click="cancelConfig" class="cancel-button">Cancel</button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { useApiStore } from '@/stores/api';

const router = useRouter();
const apiStore = useApiStore();
const currentApiUrl = ref('');

onMounted(() => {
  currentApiUrl.value = apiStore.apiBaseUrl;
});

const saveConfig = () => {
  // Basic validation
  if (currentApiUrl.value.trim() === '') {
    alert('API Base URL cannot be empty.');
    return;
  }
  apiStore.setApiBaseUrl(currentApiUrl.value);
  alert('API Base URL saved successfully!');
  router.back(); // Go back to the previous page
};

const cancelConfig = () => {
  router.back(); // Go back to the previous page
};
</script>

<style scoped>
.config-container {
  max-width: 500px;
  margin: 50px auto;
  padding: 30px;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  background-color: #fff;
}

h2 {
  text-align: center;
  color: #333;
  margin-bottom: 25px;
}

.input-group {
  margin-bottom: 20px;
}

.input-group label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
  color: #555;
}

.input-group input[type="text"] {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  box-sizing: border-box; /* Include padding in width */
}

.button-group {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 25px;
}

.save-button, .cancel-button {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  font-weight: bold;
  transition: background-color 0.2s ease;
}

.save-button {
  background-color: #007bff;
  color: white;
}

.save-button:hover {
  background-color: #0056b3;
}

.cancel-button {
  background-color: #6c757d;
  color: white;
}

.cancel-button:hover {
  background-color: #5a6268;
}
</style>
