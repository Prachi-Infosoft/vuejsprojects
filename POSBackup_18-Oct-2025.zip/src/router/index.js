import { createRouter, createWebHistory } from 'vue-router';
import HomeView from '../views/HomeView.vue';
import DBList from '@/components/DBList.vue';
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import('../views/AboutView.vue'),
    },
    {
      path:'/dblist',
      name:'dblist',
      component:DBList
    },
    {
      path: '/stock',
      name: 'stock',
      component: () => import('../views/StockView.vue')
    },
    {
      path: '/invoices',
      name: 'invoices',
      component: () => import('../views/InvoiceView.vue')
    },
        {
          path: '/invoices/new',
          name: 'new-invoice',
          component: () => import('../views/NewInvoice.vue'),
          props: true
        },
        {
          path: '/config',
          name: 'config',
          component: () => import('../views/ConfigView.vue')
        }
      ],
    });
export default router;