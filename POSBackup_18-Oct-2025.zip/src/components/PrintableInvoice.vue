<template>
  <div class="invoice-box">
    <table cellpadding="0" cellspacing="0">
      <tr class="top">
        <td colspan="2">
          <table>
            <tr>
              <td class="title">
                <img
                  :src="logoPath"
                  style="width: 100%; max-width: 100px"
                />
              </td>

              <td>
                Invoice #: {{ invoice.id }}<br />
                Created: {{ invoice.edate }}<br />
                <!-- Due: February 1, 2023 -->
              </td>
            </tr>
          </table>
        </td>
      </tr>

      <tr class="information">
        <td colspan="2">
          <table>
            <tr>
              <td>
                <!-- Sparksuite, Inc.<br />
                12345 Sunny Road<br />
                Sunnyville, CA 12345 -->
              </td>

              <td>
                {{ invoice.partyname }}<br />
                <!-- John Doe<br />
                john@example.com -->
              </td>
            </tr>
          </table>
        </td>
      </tr>

      <tr class="heading">
        <td>Payment Method</td>

        <td>Check #</td>
      </tr>

      <tr class="details">
        <td>Cash</td>

        <td>-</td>
      </tr>

      <tr class="heading">
        <td>Item</td>

        <td>Price</td>
      </tr>

      <tr class="item" v-for="(item, index) in invoice.invoiceitem" :key="index">
        <td>{{ item.itemname }}</td>

        <td>{{ formatCurrency(item.amount) }}</td>
      </tr>

      <tr class="total">
        <td></td>

        <td>Total: {{ formatCurrency(calculateTotal(invoice)) }}</td>
      </tr>
    </table>
  </div>
</template>

<script setup>
import { defineProps, computed } from 'vue';

defineProps({
  invoice: {
    type: Object,
    required: true,
  },
});

const calculateTotal = (invoice) => {
  return invoice.invoiceitem.reduce((total, item) => total + item.amount, 0);
};

const formatCurrency = (value) => {
  if (typeof value !== 'number') {
        return '0.00';
    }
  return value.toFixed(2);
};

const logoPath = computed(() => {
  return `${import.meta.env.BASE_URL}logo1.png`;
});</script>

<style scoped>
.invoice-box {
  max-width: 800px;
  margin: auto;
  padding: 30px;
  border: 1px solid #eee;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
  font-size: 16px;
  line-height: 24px;
  font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
  color: #555;
}

.invoice-box table {
  width: 100%;
  line-height: inherit;
  text-align: left;
}

.invoice-box table td {
  padding: 5px;
  vertical-align: top;
}

.invoice-box table tr td:nth-child(2) {
  text-align: right;
}

.invoice-box table tr.top table td {
  padding-bottom: 20px;
}

.invoice-box table tr.top table td.title {
  font-size: 45px;
  line-height: 45px;
  color: #333;
}

.invoice-box table tr.information table td {
  padding-bottom: 40px;
}

.invoice-box table tr.heading td {
  background: #eee;
  border-bottom: 1px solid #ddd;
  font-weight: bold;
}

.invoice-box table tr.details td {
  padding-bottom: 20px;
}

.invoice-box table tr.item td {
  border-bottom: 1px solid #eee;
}

.invoice-box table tr.item.last td {
  border-bottom: none;
}

.invoice-box table tr.total td:nth-child(2) {
  border-top: 2px solid #eee;
  font-weight: bold;
}

@media only screen and (max-width: 600px) {
  .invoice-box table tr.top table td {
    width: 100%;
    display: block;
    text-align: center;
  }

  .invoice-box table tr.information table td {
    width: 100%;
    display: block;
    text-align: center;
  }
}

/** RTL **/
.invoice-box.rtl {
  direction: rtl;
  font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
}

.invoice-box.rtl table {
  text-align: right;
}

.invoice-box.rtl table tr td:nth-child(2) {
  text-align: left;
}
</style>
