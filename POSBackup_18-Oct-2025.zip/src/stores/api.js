import { defineStore } from 'pinia';
import { ref, computed } from 'vue';

export const useApiStore = defineStore('api', () => {
  const rawApiBaseUrl = ref(localStorage.getItem('apiBaseUrl') || '');
  console.log('ApiStore: Initial rawApiBaseUrl from localStorage:', rawApiBaseUrl.value);

  const apiBaseUrl = computed(() => {
    // Ensure no trailing slash
    return rawApiBaseUrl.value.endsWith('/')
      ? rawApiBaseUrl.value.slice(0, -1)
      : rawApiBaseUrl.value;
  });

  function setApiBaseUrl(url) {
    rawApiBaseUrl.value = url;
    localStorage.setItem('apiBaseUrl', url);
    console.log('ApiStore: rawApiBaseUrl set to:', rawApiBaseUrl.value);
  }

  return { apiBaseUrl, setApiBaseUrl };
});
