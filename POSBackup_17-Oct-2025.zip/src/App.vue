<template>
  <div id="app">
    <!-- Main Navbar -->
    <nav class="navbar">
      <div class="navbar-start">
        <button @click="isDrawerOpen = true" class="hamburger-button">&#9776;</button>
        <div class="navbar-brand">
          <a class="navbar-item" href="#">POS</a>
        </div>
      </div>
      <div class="navbar-end">
        <ServerStatus />
      </div>
    </nav>

    <!-- Drawer Menu -->
    <DrawerMenu :show="isDrawerOpen" @close="isDrawerOpen = false">
      <!-- Logged-out Menu -->
      <div v-if="!session.isAuthenticated">
        <a class="drawer-item" @click="navigateTo('/dblist')">Open Database</a>
        <a class="drawer-item" @click="navigateTo('/config')">Config</a>
      </div>

      <!-- Logged-in Menu -->
      <div v-else>
        <a class="drawer-item" @click="navigateTo('/stock')">Stock Item</a>
        <a class="drawer-item" @click="notImplemented">Party</a>
        <a class="drawer-item" @click="navigateTo('/invoices')">Invoices</a>
        <hr class="drawer-divider"/>
        <a class="drawer-item" @click="handleLogout">Close Company</a>
      </div>
    </DrawerMenu>

    <!-- Main Content -->
    <router-view></router-view>
   
  </div>
   
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useSessionStore } from '@/stores/session';
import ServerStatus from './components/Serverstatus.vue';
import DrawerMenu from './components/DrawerMenu.vue';
import DBList from './components/DBList.vue';
const router = useRouter();
const session = useSessionStore();
const isDrawerOpen = ref(false);

const navigateTo = (path) => {
  router.push(path);
  isDrawerOpen.value = false; // Close drawer on navigation
};

const handleLogout = () => {
  session.logout();
  navigateTo('/'); // Redirect and close drawer
};

const notImplemented = () => {
  alert('This feature is not yet implemented.');
  isDrawerOpen.value = false; // Close drawer
};
</script>

<style>
/* Keep existing navbar styles, but add/adjust for hamburger */
.navbar {
  background-color: #f2f2f2;
  padding: 10px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.navbar-start, .navbar-end {
  display: flex;
  align-items: center;
}

.navbar-end {
  margin-left: auto;
}

.hamburger-button {
  font-size: 1.5em;
  background: none;
  border: none;
  cursor: pointer;
  margin-right: 15px;
}

.navbar-brand .navbar-item {
  font-weight: bold;
  font-size: 1.2em;
  padding: 0;
}

/* Styles for items inside the drawer */
.drawer-item {
  display: block;
  padding: 15px 10px;
  color: #333;
  text-decoration: none;
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
}

.drawer-item:hover {
  background-color: #f9f9f9;
}

.drawer-divider {
  margin: 10px 0;
  border: 0;
  border-top: 1px solid #eee;
}
</style>