<template>
  <div class="container">
    <div class="header">
        <h2>Invoices</h2>
        <div class="actions">
            <button class="action-button" @click="router.push('/invoices/new')">Add New Invoice</button>
            <button class="action-button">Filter by Date</button>
        </div>
    </div>

    <input
      type="text"
      v-model="searchQuery"
      placeholder="Search by party name..."
      class="search-box"
    />

    <div class="invoice-list-container">
        <div v-if="loading" class="loading">Loading...</div>
        <div v-if="error" class="error">{{ error }}</div>

        <ul v-if="filteredInvoices.length" class="invoice-list">
          <li v-for="invoice in filteredInvoices" :key="invoice.id" class="invoice-card">
            <div class="invoice-header" @click="toggleInvoice(invoice)">
                <div class="header-content">
                    <div class="header-main-line">
                        <span>{{ invoice.edate }}</span>
                        <strong>{{ invoice.partyname }}</strong>
                        <span class="total-amount">{{ formatCurrency(calculateTotal(invoice)) }}</span>
                    </div>
                    <div class="header-sub-line">
                        <span>Entered by: {{ invoice.enterredby }}</span>
                    </div>
                </div>
                <span class="explode-symbol">{{ invoice.isExpanded ? 'v' : '›' }}</span>
            </div>
            <div v-if="invoice.isExpanded">
              <div class="item-list-header">
                  <span>Item Name</span>
                  <span>Qty</span>
                  <span>Rate</span>
                  <span class="amount-header">Amount</span>
              </div>
              <ul class="item-list-inner">
                <li v-for="(item, index) in invoice.invoiceitem" :key="index" class="item-card-inner">
                  <div class="item-line">
                    <span>{{ item.itemname }}</span>
                    <span>{{ item.qty }}</span>
                    <span>{{ item.rate }}</span>
                    <span class="amount">{{ formatCurrency(item.amount) }}</span>
                  </div>
                </li>
              </ul>
            </div>
          </li>
        </ul>
        <div v-else-if="!loading" class="no-results">
          No invoices found.
        </div>
    </div>

    <div v-if="filteredInvoices.length" class="total-line">
        <strong>Grand Total</strong>
        <span class="total-amount">{{ formatCurrency(grandTotal) }}</span>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const invoices = ref([]);
const loading = ref(true);
const error = ref(null);
const searchQuery = ref('');

onMounted(async () => {
  try {
    const response = await fetch('/api/POS/ListOfAllinvoices?fromdate=1&todate=22001231&companyno=999');
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data = await response.json();
    invoices.value = data.data.map(invoice => ({ ...invoice, isExpanded: false }));
  } catch (e) {
    error.value = 'Failed to fetch invoices: ' + e.message;
    console.error(e);
  } finally {
    loading.value = false;
  }
});

const calculateTotal = (invoice) => {
  return invoice.invoiceitem.reduce((total, item) => total + item.amount, 0);
};

const formatCurrency = (value) => {
  if (typeof value !== 'number') {
        return '0.00';
    }
  return value.toFixed(2);
};

const toggleInvoice = (invoice) => {
  invoice.isExpanded = !invoice.isExpanded;
};

const filteredInvoices = computed(() => {
  if (!searchQuery.value) {
    return invoices.value;
  }
  return invoices.value.filter(invoice =>
    invoice.partyname.toLowerCase().includes(searchQuery.value.toLowerCase())
  );
});

const grandTotal = computed(() => {
    return filteredInvoices.value.reduce((total, invoice) => total + calculateTotal(invoice), 0);
});
</script>

<style scoped>
.container {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 80px); /* Increased height */
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.actions {
    display: flex;
    gap: 10px;
}

.action-button {
    padding: 8px 12px;
    border: none;
    background-color: #007aff;
    color: white;
    border-radius: 8px;
    cursor: pointer;
}

.invoice-list-container {
    flex-grow: 1;
    overflow-y: auto;
}

h2 {
  text-align: center;
  margin: 0;
}

.search-box {
  width: 100%;
  padding: 12px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 16px;
}

.loading, .no-results, .error {
  text-align: center;
  padding: 20px;
  color: #888;
}

.error {
  color: #f14668;
}

.invoice-list {
  list-style: none;
  padding: 0;
}

.invoice-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  margin-bottom: 10px;
  padding: 15px;
}

.invoice-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
}

.header-content {
    flex-grow: 1;
}

.header-main-line {
    display: flex;
    justify-content: space-between;
    width: 100%;
}

.header-sub-line {
    font-size: 0.8em;
    color: #6c757d;
    margin-top: 4px;
}

.invoice-header strong {
  font-size: 1.2em;
  flex-grow: 1;
  padding: 0 10px;
}

.total-amount {
  font-weight: bold;
  text-align: right;
}

.explode-symbol {
    font-size: 1.2em; /* Lighter font */
    font-weight: normal;
    margin-left: 15px;
    width: 20px; /* Fixed width for alignment */
    text-align: center;
}

.item-list-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background-color: #87ceeb; /* skyblue */
    font-weight: bold;
    margin-top: 15px;
    border-top: 1px solid #eee;
}

.amount-header {
    text-align: right;
}

.item-list-inner {
  list-style: none;
  padding: 0;
}

.item-card-inner {
  padding: 0 10px;
  border-bottom: 1px solid #eee;
}

.item-card-inner:last-child {
  border-bottom: none;
}

.item-line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  font-size: 0.8em; /* tiny font */
  color: #0000ff; /* blue */
}

.amount {
  text-align: right;
}

.total-line {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    margin-top: 20px;
    border-top: 2px solid #333;
    font-size: 1.2em;
}
</style>