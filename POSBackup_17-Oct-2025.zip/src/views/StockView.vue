<template>
  <div class="container">
    <div class="header">
      <h2>Stock Items</h2>
      <button class="add-button">Add New Item</button>
    </div>

    <input
      type="text"
      v-model="searchQuery"
      placeholder="Search items..."
      class="search-box"
    />

    <div v-if="loading" class="loading">Loading...</div>
    <div v-if="error" class="error">{{ error }}</div>

    <ul v-if="filteredItems.length" class="item-list">
      <li v-for="item in filteredItems" :key="item.id" class="item-card">
        <div class="item-line"><strong>{{ item.name }}</strong></div>
        <div class="item-line">
          <span>Barcode: {{ item.barcode }}</span>
          <span class="uom">UOM: {{ item.uom }}</span>
        </div>
        <div class="item-line">
          <span>Rate: {{ item.preRate }}</span>
          <span>Qty: {{ item.closingQty }}</span>
        </div>
      </li>
    </ul>
    <div v-else-if="!loading" class="no-results">
      No stock items found.
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';

const stockItems = ref([]);
const loading = ref(true);
const error = ref(null);
const searchQuery = ref('');

onMounted(async () => {
  try {
    const response = await fetch('/api/POS/ListOfAllItems?companyno=999');
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data = await response.json();
    stockItems.value = data.data;
  } catch (e) {
    error.value = 'Failed to fetch stock items: ' + e.message;
    console.error(e);
  } finally {
    loading.value = false;
  }
});

const filteredItems = computed(() => {
  if (!searchQuery.value) {
    return stockItems.value;
  }
  return stockItems.value.filter(item =>
    item.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
    item.barcode.toLowerCase().includes(searchQuery.value.toLowerCase())
  );
});
</script>

<style scoped>
.container {
  padding: 20px;
  max-width: 600px;
  margin: 0 auto;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

h2 {
  margin: 0;
}

.add-button {
  padding: 8px 12px;
  border: none;
  background-color: #007aff;
  color: white;
  border-radius: 8px;
  cursor: pointer;
}

.search-box {
  width: 100%;
  padding: 12px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 16px;
}

.loading, .no-results, .error {
  text-align: center;
  padding: 20px;
  color: #888;
}

.error {
  color: #f14668;
}

.item-list {
  list-style: none;
  padding: 0;
}

.item-card {
  padding: 15px;
  border-bottom: 1px solid #eee;
}

.item-card:last-child {
  border-bottom: none;
}

.item-line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 4px 0;
}

.item-line strong {
  font-size: 1.1em;
}

.uom {
  font-style: italic;
}
</style>