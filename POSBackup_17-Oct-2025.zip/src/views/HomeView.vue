<template>
  <div class="home-view-container">
    <!--
    <h1>External Content (prachi-infosoft.github.io)</h1>
    -->
    <iframe
      src="https://prachi-infosoft.github.io/"
      class="external-iframe"
      title="Prachi Infosoft External Page"
      sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
    >
      <p>Your browser does not support iframes.</p>
    </iframe>
    <!--
    <p>The content above is loaded directly from the external URL using an iframe.</p>
    -->
  </div>
</template>

<script setup>
// No script setup logic needed for fetching, as the iframe handles the loading
// The component is now much simpler!
</script>

<style scoped>
.home-view-container {
  padding: 20px;
  font-family: sans-serif;
  height: 100vh; /* Set a height for the container */
}

.external-iframe {
  /* This ensures the iframe fills the available space and looks good */
  width: 100%;
  height: 80vh; /* Adjust height as needed */
  border: 1px solid #ddd;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
</style>