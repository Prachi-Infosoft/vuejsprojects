<template>
  <div class="new-invoice-layout">
    <div class="invoice-form-container">
      <div class="invoice-form">
        <div class="form-header">
          <h2>New Invoice</h2>
          <input type="text" placeholder="Invoice Number" class="invoice-number-input"/>
          <button @click="sendInvoice" class="send-btn">Save Invoice</button>
        </div>

        <div class="customer-info">
            <input type="text" placeholder="Customer Name" v-model="customerName" @focus="showParties" @input="filterParties" />
        </div>

        <table class="items-table">
            <thead>
                <tr>
                    <th>Actions</th>
                    <th>Item Name</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(item, index) in items" :key="index">
                    <td>
                        <button @click="editItem(index)" class="action-btn">✏️</button>
                        <button @click="removeItem(index)" class="action-btn">❌</button>
                    </td>
                    <td>{{ item.name }}</td>
                    <td>{{ item.qty }}</td>
                    <td>{{ item.price }}</td>
                    <td>{{ (item.qty * item.price).toFixed(2) }}</td>
                </tr>
            </tbody>
        </table>

        <div class="total-section">
            <strong>Total: {{ total.toFixed(2) }}</strong>
        </div>

        <div class="add-item-form">
            <input v-model="currentItem.name" placeholder="Enter item name" @focus="showStock" />
            <input v-model.number="currentItem.qty" type="number" placeholder="Qty" />
            <input v-model.number="currentItem.price" type="number" placeholder="Price" />
            <button @click="addItem" class="add-btn">{{ editingIndex === null ? 'Add' : 'Update' }}</button>
        </div>
      </div>
    </div>
    <div class="suggestion-container">
        <div v-if="rightPanelContent === 'stock'">
            <h3>Stock Items</h3>
            <ul class="suggestion-list">
                <li v-for="item in filteredStockItems" :key="item.id" @click="selectStockItem(item)" class="suggestion-item">
                    <strong>{{ item.name }}</strong>
                    <div>Rate: {{ item.preRate }} | Qty: {{ item.closingQty }}</div>
                </li>
            </ul>
        </div>
        <div v-if="rightPanelContent === 'parties'">
            <h3>Customers</h3>
            <ul class="suggestion-list">
                <li v-for="party in filteredParties" :key="party.id" @click="selectParty(party)" class="suggestion-item">
                    <strong>{{ party.name }}</strong>
                    <div>Balance: {{ party.balance }}</div>
                </li>
            </ul>
        </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';

const items = ref([]);
const currentItem = ref({ name: "", qty: null, price: null });
const editingIndex = ref(null);
const stockItems = ref([]);
const parties = ref([]);
const customerName = ref('');
const rightPanelContent = ref('stock'); // 'stock' or 'parties'

const total = computed(() => {
  return items.value.reduce((sum, i) => sum + i.qty * i.price, 0);
});

const filteredStockItems = computed(() => {
    if (!currentItem.value.name) {
        return stockItems.value;
    }
    return stockItems.value.filter(item =>
        item.name.toLowerCase().includes(currentItem.value.name.toLowerCase())
    );
});

const filteredParties = computed(() => {
    if (!customerName.value) {
        return parties.value;
    }
    return parties.value.filter(party =>
        party.name.toLowerCase().includes(customerName.value.toLowerCase())
    );
});

const addItem = () => {
  if (!currentItem.value.name || !currentItem.value.qty || !currentItem.value.price) return;

  if (editingIndex.value !== null) {
    items.value[editingIndex.value] = { ...currentItem.value };
    editingIndex.value = null;
  } else {
    items.value.push({ ...currentItem.value });
  }

  currentItem.value = { name: "", qty: null, price: null };
};

const editItem = (index) => {
  currentItem.value = { ...items.value[index] };
  editingIndex.value = index;
};

const removeItem = (index) => {
  items.value.splice(index, 1);
};

const selectStockItem = (stockItem) => {
    currentItem.value.name = stockItem.name;
    currentItem.value.price = stockItem.preRate;
};

const selectParty = (party) => {
    customerName.value = party.name;
    rightPanelContent.value = 'stock'; // Switch back to stock after selection
};

const showParties = () => {
    rightPanelContent.value = 'parties';
};

const showStock = () => {
    rightPanelContent.value = 'stock';
};

const sendInvoice = async () => {
  try {
    const response = await fetch("/api/invoice", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items: items.value, total: total.value, customer: customerName.value }),
    });
    alert("Invoice sent!");
  } catch (err) {
    alert("Failed to send invoice.");
  }
};

onMounted(async () => {
  try {
    const [stockResponse, partyResponse] = await Promise.all([
        fetch('/api/POS/ListOfAllItems?companyno=999'),
        fetch('/api/POS/ListOfAllPersons?companyno=999')
    ]);

    if (!stockResponse.ok) throw new Error('Failed to fetch stock items');
    if (!partyResponse.ok) throw new Error('Failed to fetch parties');

    const stockData = await stockResponse.json();
    const partyData = await partyResponse.json();

    stockItems.value = stockData.data;
    parties.value = partyData.data;

  } catch (e) {
    console.error(e);
  }
});
</script>

<style scoped>
.new-invoice-layout {
    display: flex;
    height: 100vh;
    background-color: #f9f9f9;
}

.invoice-form-container {
    width: 60%;
    padding: 20px;
    display: flex;
    flex-direction: column;
}

.invoice-form {
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 20px;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.form-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.invoice-number-input {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
    margin: 0 15px;
}

.send-btn {
    background-color: #007aff;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
}

.customer-info {
    margin-bottom: 20px;
}

.customer-info input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
}

.items-table {
    width: 100%;
    border-collapse: collapse;
    flex-grow: 1;
}

.items-table th, .items-table td {
    padding: 8px; /* Reduced padding */
    border-bottom: 1px solid #eee;
    text-align: left;
}

.items-table th {
    background-color: #f2f2f2;
}

.action-btn {
    border: none;
    background: none;
    cursor: pointer;
}

.total-section {
    text-align: right;
    margin-top: 20px;
    font-size: 1.2em;
    font-weight: bold;
}

.add-item-form {
    display: flex;
    gap: 10px;
    margin-top: 20px;
    align-items: center;
}

.add-item-form input {
    flex-grow: 1;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
}

.add-btn {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
}

.suggestion-container {
    width: 40%;
    padding: 20px;
    border-left: 1px solid #ddd;
    overflow-y: auto;
    background-color: #f9f9f9;
}

.suggestion-list {
    list-style: none;
    padding: 0;
}

.suggestion-item {
    padding: 10px;
    border-bottom: 1px solid #eee;
    cursor: pointer;
}

.suggestion-item:hover {
    background-color: #f0f0f0;
}
</style>
