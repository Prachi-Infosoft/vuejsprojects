<template>
  <div class="about-view-container">
    
    <section class="hero-section">
      <div class="hero-content">
        <p class="tagline">More than just code, we build futures.</p>
        <h1>Our Journey, Our Purpose.</h1>
      </div>
    </section>

    <section class="story-section">
      <div class="story-image-placeholder">
        
      </div>
      <div class="story-text">
        <h2 class="section-title">The Origin Story</h2>
        <p>
          It all began in a small garage in 2018 with a single vision: to simplify complex digital solutions. Our founder, **[Founder Name]**, noticed a gap between high-end development and genuine client partnership. We set out to bridge that gap, prioritizing **transparency and quality** above all else.
        </p>
        <p>
          Today, we are a global team, but our garage-born values remain the core of every project we undertake.
        </p>
        <router-link to="/contact" class="cta-button primary">
          Connect With Our Team
        </router-link>
      </div>
    </section>

    <hr class="divider">

    <section class="values-section">
      <h2 class="section-title center">Our Guiding Principles</h2>
      <div class="values-grid">
        <div class="value-card">
          <span class="icon">💡</span>
          <h3>Innovation</h3>
          <p>We constantly seek new technologies and ideas to deliver forward-thinking solutions that keep our clients ahead of the curve.</p>
        </div>
        <div class="value-card">
          <span class="icon">🤝</span>
          <h3>Integrity</h3>
          <p>Honesty and transparency are non-negotiable. We build trust by always communicating openly and meeting our commitments.</p>
        </div>
        <div class="value-card">
          <span class="icon">🎯</span>
          <h3>Impact</h3>
          <p>We measure our success not just by the projects we complete, but by the tangible, positive impact they have on our clients' business goals.</p>
        </div>
      </div>
    </section>

    <section class="team-section">
      <h2 class="section-title center">Meet the Makers</h2>
      <div class="team-grid">
        <div class="team-member-card">
          <div class="member-photo">[Photo Placeholder]</div>
          <h4>Jane Doe</h4>
          <p class="role">Chief Executive Officer</p>
        </div>
        <div class="team-member-card">
          <div class="member-photo">[Photo Placeholder]</div>
          <h4>John Smith</h4>
          <p class="role">Lead Developer</p>
        </div>
        <div class="team-member-card">
          <div class="member-photo">[Photo Placeholder]</div>
          <h4>Alice Brown</h4>
          <p class="role">Head of Design</p>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
// No specific data or methods are needed for this static content component
// Use JavaScript for any dynamic team data or animation logic if required
</script>

<style scoped>
/* --- Component Variables and Setup --- */
:root {
  --primary-color: #007BFF;
  --secondary-color: #f8f9fa;
  --text-color: #343a40;
  --light-text-color: #6c757d;
  --padding-y: 80px;
}

.about-view-container {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: var(--text-color);
  line-height: 1.6;
}

section {
  padding: var(--padding-y) 5%;
  max-width: 1200px;
  margin: 0 auto;
}

.section-title {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 40px;
  color: var(--primary-color);
  text-transform: uppercase;
  letter-spacing: 1px;
}
.center {
    text-align: center;
}

/* --- 1. Hero Section --- */
.hero-section {
  background: var(--primary-color);
  color: white;
  padding: 120px 5%;
  text-align: center;
}
.hero-content h1 {
  font-size: 4rem;
  margin-bottom: 10px;
}
.tagline {
  font-size: 1.25rem;
  font-style: italic;
  opacity: 0.8;
}

/* --- 2. Story Section --- */
.story-section {
  display: grid;
  grid-template-columns: 1fr;
  gap: 60px;
  align-items: center;
}
@media (min-width: 768px) {
  .story-section {
    grid-template-columns: 1.2fr 1.8fr; /* Image takes less space than text */
    padding-left: 0;
    padding-right: 0;
  }
}

.story-image-placeholder {
  height: 400px;
  background-color: var(--secondary-color);
  display: flex;
  justify-content: center;
  align-items: center;
  font-style: italic;
  color: var(--light-text-color);
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.story-text p {
  margin-bottom: 20px;
  font-size: 1.1rem;
}

.cta-button {
  display: inline-block;
  padding: 12px 25px;
  margin-top: 20px;
  border-radius: 50px;
  text-decoration: none;
  font-weight: bold;
  transition: background-color 0.3s, transform 0.3s;
}
.primary {
  background-color: var(--primary-color);
  color: white;
}
.primary:hover {
  background-color: #0056b3;
  transform: translateY(-2px);
}

.divider {
    border: 0;
    height: 1px;
    background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 123, 255, 0.75), rgba(0, 0, 0, 0));
    margin: 40px 0;
}

/* --- 3. Values Section --- */
.values-section {
  background-color: var(--secondary-color);
  text-align: center;
}

.values-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 30px;
}

.value-card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s;
}
.value-card:hover {
    transform: translateY(-5px);
}

.value-card .icon {
  font-size: 3rem;
  display: block;
  margin-bottom: 15px;
}

.value-card h3 {
  font-size: 1.5rem;
  margin-bottom: 10px;
  color: var(--primary-color);
}

/* --- 4. Team Section --- */
.team-grid {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 30px;
  margin-top: 40px;
}

.team-member-card {
  text-align: center;
  width: 200px;
}

.member-photo {
  width: 150px;
  height: 150px;
  background-color: #dee2e6;
  border-radius: 50%;
  margin: 0 auto 15px;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 3px solid var(--primary-color);
  font-size: 0.9rem;
  color: var(--light-text-color);
}

.team-member-card h4 {
  margin: 0;
  font-size: 1.25rem;
}

.team-member-card .role {
  color: var(--light-text-color);
  font-size: 0.9rem;
}
</style>