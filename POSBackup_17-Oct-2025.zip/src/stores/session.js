// src/stores/session.js
import { defineStore } from 'pinia'

export const useSessionStore = defineStore('session', {
  // 1. STATE: The data properties
  state: () => ({
    // The main object to hold connection details
    connectionDetails: {
      svdbname: '',
      svuser: '',
      svpassword: ''
    },
    // Session state flag
    isLoggedIn: false,
    isServerOnline: true, // New state for server status
  }),

  // 2. GETTERS: Computed properties based on state (optional but useful)
  getters: {
    isAuthenticated: (state) => state.isLoggedIn,
    getDbName: (state) => state.connectionDetails.svdbname
  },

  // 3. ACTIONS: Methods to modify the state (where login/logout logic goes)
  actions: {
    // Initializes/updates the connection object and performs login
    login(dbName, user, password) {
      // Create and Initialize the object properties
      this.connectionDetails.svdbname = dbName
      this.connectionDetails.svuser = user
      this.connectionDetails.svpassword = password

      // Set the session state
      this.isLoggedIn = true

      console.log('Login Event: Session started successfully.')
    },

    // Resets the object and logs out the user
    logout() {
      // Clear the object properties
      this.connectionDetails.svdbname = ''
      this.connectionDetails.svuser = ''
      this.connectionDetails.svpassword = ''

      // Clear the session state
      this.isLoggedIn = false

      console.log('Logout Event: Session ended.')
      // You can also trigger router push here, e.g., router.push('/login')
    },

    // A method to initialize the object without logging in (optional)
    initializeDetails(details) {
      this.connectionDetails = details;
    },

    // Action to update server status
    setServerStatus(status) {
      this.isServerOnline = status;
    },

    // Action to check server status
    async checkServerStatus() {
      try {
        const response = await fetch('/api/pos');
        this.setServerStatus(response.ok);
      } catch (error) {
        this.setServerStatus(false);
      }
    },
  }
})