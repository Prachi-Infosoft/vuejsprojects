<template>
  <div class="navbar-item">
    <button :class="statusClass" @click="session.checkServerStatus">
      {{ status }}
    </button>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue';
import { useSessionStore } from '@/stores/session';

const session = useSessionStore();

const status = computed(() => {
  return session.isServerOnline ? 'Online' : 'Offline';
});

const statusClass = computed(() => ({
  'button': true,
  'is-success': session.isServerOnline,
  'is-danger': !session.isServerOnline,
  'is-small': true,
}));

onMounted(() => {
  session.checkServerStatus();
});
</script>

<style scoped>
.button {
  border: none;
  padding: 0.5em 1em;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}
.is-success {
  background-color: #48c774;
  color: white;
}
.is-danger {
  background-color: #f14668;
  color: white;
}
.is-small {
  font-size: 0.75rem;
}
</style>