<template>
  <div class="container">
    <h2>Database List</h2>

    <input
      type="text"
      v-model="searchQuery"
      placeholder="Search databases..."
      class="search-box"
    />

    <div v-if="loading" class="loading">Loading...</div>
    <div v-if="error" class="error">{{ error }}</div>

    <ul v-if="filteredDatabases.length" class="db-list">
      <li v-for="db in filteredDatabases" :key="db.id" class="db-item">
        <span class="db-name">{{ db.name }}</span>
        <span class="db-dosname">DOS Name: {{ db.dosname }}</span> <!-- Added dosname display -->
        <button @click="openLoginModal(db)" class="open-button">Open</button>
        <hr class="divider" />
      </li>
    </ul>
    <div v-else-if="!loading && !sessionStore.isServerOnline" class="error">
      {{ error }}
    </div>
    <div v-else-if="!loading && filteredDatabases.length === 0" class="no-results">
      No databases found.
    </div>

    <!-- Modal for Login -->

  <Modal :show="isModalOpen" @close="isModalOpen = false">
    <div v-if="selectedDb">
      <h3>Login to {{ selectedDb.name }}</h3>
      <div class="modal-form">
        <input type="text" v-model="username" placeholder="Username" />
        <input type="password" v-model="password" placeholder="Password" @keyup.enter="handleConnect" />
        <button @click="handleConnect" class="connect-button">Connect</button>
      </div>
      <p v-if="modalError" class="error">{{ modalError }}</p>
    </div>
  </Modal>


  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router'; // Import router

import Modal from './Model.vue';
import { useSessionStore } from '@/stores/session';

// --- Router ---
const router = useRouter(); // Initialize router


// --- Component State ---
const databases = ref([]);
const loading = ref(true);
const error = ref(null);
const searchQuery = ref('');

// --- Pinia Store ---
const sessionStore = useSessionStore();

// --- Modal State ---
const isModalOpen = ref(false);
const selectedDb = ref(null);
const username = ref('');
const password = ref('');
const modalError = ref('');



onMounted(async () => {
  try {
    // 1. Check server status using the store action
    await sessionStore.checkServerStatus();

    // 2. If server is online, fetch databases
    if (sessionStore.isServerOnline) {
      const dbResponse = await fetch('/api/pos/listofdatabases');
      if (!dbResponse.ok) throw new Error('Network response was not ok when fetching databases.');
      
      const data = await dbResponse.json();
      databases.value = data.data;
    } else {
      // Set a specific error if the server is offline
      throw new Error('Server is offline or not responding.');
    }

  } catch (e) {
    error.value = e.message;
    console.error(e);
  } finally {
    loading.value = false;
  }
});

const filteredDatabases = computed(() => {
  if (!searchQuery.value) return databases.value;
  return databases.value.filter(db =>
    db.name.toLowerCase().includes(searchQuery.value.toLowerCase())
  );
});

const openLoginModal = (db) => {
  selectedDb.value = db;
  isModalOpen.value = true;
  modalError.value = '';
  username.value = '';
  password.value = '';
};

const handleConnect = async () => {
  if (!username.value || !password.value) {
    modalError.value = 'Please enter both username and password.';
    return;
  }

  modalError.value = '';

  try {
    //const url = `user/validateuser?companyno=${selectedDb.value.dosname}`;
    const url = `/api/user/validateuser?companyno=${selectedDb.value.dosname}`;
    const body = {
      name: username.value,
      passcredential: password.value,
    };

    // Log the JSON body before sending
    console.log('Sending to server:', JSON.stringify(body, null, 2));

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    const result = await response.json();

    if (!response.ok || !result.isvalid) {
      const message = result.message || 'Invalid username or password.';
      throw new Error(message);
    }

    sessionStore.login(
      selectedDb.value.name,
      result.name,
      password.value
    );

    console.log('Login successful:', result);
    router.push('/home'); // Redirect to home page
    
    isModalOpen.value = false;

  } catch (e) {
    modalError.value = e.message;
    console.error('Failed to connect:', e);
  }
};
</script>

<style scoped>
.container {
  padding: 20px;
  max-width: 600px;
  margin: 0 auto;
}

h2, h3 {
  margin-bottom: 20px;
  text-align: center;
}

.search-box {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.db-list {
  list-style: none;
  padding: 0;
}

.db-item {
  margin-bottom: 10px;
}

.db-name {
  font-size: 1.2em;
  font-weight: bold;
  display: block; /* Ensures it takes its own line */
}

.db-dosname {
  display: block; /* Ensures it takes its own line */
  font-size: 0.8rem; /* Tiny font */
  color: #6c757d;   /* A muted color */
  margin-top: 4px;
}

.open-button {
  display: block;
  margin-top: 10px;
  padding: 5px 10px;
  border: 1px solid #007bff;
  background-color: #007bff;
  color: white;
  border-radius: 4px;
  cursor: pointer;
}

.open-button:hover {
  background-color: #0056b3;
}

.divider {
  border: 0;
  border-top: 1px solid #eee;
  margin-top: 20px;
}

.loading, .no-results {
  text-align: center;
  padding: 20px;
  color: #888;
}

.error {
  color: #f14668;
  text-align: center;
  margin-top: 10px;
}

/* Modal specific styles */
.modal-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.modal-form input {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 1em;
}

.connect-button {
  padding: 10px 15px;
  border: none;
  background-color: #28a745;
  color: white;
  border-radius: 4px;
  cursor: pointer;
  align-self: center;
  margin-top: 10px;
}

.connect-button:hover {
  background-color: #218838;
}
</style>
