<template>
  <div>
    <!-- Overlay -->
    <div v-if="show" @click="$emit('close')" class="drawer-overlay"></div>

    <!-- Drawer Panel -->
    <div :class="['drawer-panel', { 'is-open': show }]">
      <div class="drawer-header">
        <h3>Menu</h3>
        <button @click="$emit('close')" class="close-button">&times;</button>
      </div>
      <div class="drawer-content">
        <!-- Content is passed here -->
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  show: {
    type: Boolean,
    required: true,
  },
});
defineEmits(['close']);
</script>

<style scoped>
.drawer-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 1000;
}

.drawer-panel {
  position: fixed;
  top: 0;
  left: -300px; /* Start off-screen */
  width: 300px;
  height: 100%;
  background-color: white;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
  transition: left 0.3s ease-in-out;
  z-index: 1001;
  display: flex;
  flex-direction: column;
}

.drawer-panel.is-open {
  left: 0; /* Slide in */
}

.drawer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px;
  border-bottom: 1px solid #eee;
}

.drawer-header h3 {
  margin: 0;
  font-size: 1.2em;
}

.close-button {
  border: none;
  background: none;
  font-size: 1.8em;
  cursor: pointer;
  color: #888;
}

.drawer-content {
  padding: 15px;
  flex-grow: 1;
  overflow-y: auto;
}
</style>
