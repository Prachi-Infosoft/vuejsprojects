import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

import { createPinia } from 'pinia' // 1. Import createPinia

const app = createApp(App)

const pinia = createPinia() // 2. Create the Pinia instance

app.use(pinia) // 3. Use Pinia

app.use(router)

app.mount('#app')
